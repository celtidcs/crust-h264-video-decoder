Bitsteam Name		:FRExt1_Panasonic
Profile			:Hi
Level			:2.1
Category		:4:2:0 8
Sequence		:Foreman
Width			:352
Height			:288

Num of Frms		:8
Entropy Coding		:CAVLC
IDR Intervals		:All I pictures
Slice per Pic		:1
Mixed Slice Type	:No
POC type		:0

Coding Type		:Frame only
Num of Ref Frms		:2

Loop Filter		:On
Constrained Intra Flag	:Off

No of B Frms		:2
Direct Type		:Spatial
Direct8x8 Inference Flag:0
Stored B Pic		:No

Transform Mode		:8x8 only
Sequence Qmatrix	:On
Picture Qmatrix		:On

MMCO			:Off
RPSL			:Off

Weighted Pred		:Off
PCM Mode		:No
Chroma Offset		:No

SP Pic Periodicity	:No
VUI			:No
SEI			:No
HRD Parameters		:No
Partition Mode		:0

Conformance Point	:L047d5
Comments		:I - B - B - P

			:Display Order ->
			: 1st IDR - SPS all
			: 2nd B   - PPS fall-back rule
			: 3rd B   - PPS all - default
			: 4th P   - PPS all
			: 5th B   - PPS all - max_min
			: 6th B   - PPS all - delta_scale
			: 7th IDR - SPS fall-back rule
			: 8th P   - PPS fall-back rule
