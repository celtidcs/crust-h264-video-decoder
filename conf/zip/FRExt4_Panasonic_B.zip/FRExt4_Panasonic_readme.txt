Bitsteam Name		:FRExt4_Panasonic
Profile			:Hi
Level			:2.1
Category		:4:2:0 8
Sequence		:Mobile
Width			:352
Height			:288

Num of Frms		:10
Entropy Coding		:CABAC
IDR Intervals		:1st I picture only
Slice per Pic		:1
Mixed Slice Type	:No
POC type		:0

Coding Type		:MBAFF/AFF
Num of Ref Frms		:3

Loop Filter		:On
Constrained Intra Flag	:Off

No of B Frms		:2
Direct Type		:Spatial
Direct8x8 Inference Flag:1
Stored B Pic		:No

Transform Mode		:8x8 only
Sequence Qmatrix	:On
Picture Qmatrix		:On

MMCO			:Off
RPSL			:Off

Weighted Pred		:Off
PCM Mode		:No
Chroma Offset		:No

SP Pic Periodicity	:No
VUI			:No
SEI			:No
HRD Parameters		:No
Partition Mode		:0

Conformance Point	:L047d10
Comments		:I - B - B - P

			:Display Order ->
			: 1st IDR - MBAFF SPS all
			: 2nd B   - FLD   PPS fall-back rule
			: 3rd B   - MBAFF PPS all - default
			: 4th P   - FLD   PPS all - max_min
			: 5th B   - MBAFF PPS fall-back rule
			: 6th B   - FLD   PPS all - delta_scale
			: 7th I   - FLD   PPS fall-back rule
			: 8th B   - FLD   PPS all - default
			: 9th B   - MBAFF PPS all - delta_scale
			:10th P   - MBAFF 
