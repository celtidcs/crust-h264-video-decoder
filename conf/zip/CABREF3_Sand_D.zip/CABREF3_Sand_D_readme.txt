Files in the folder
CABREF3_Sand_D_Readme.txt       This file
CABREF3_Sand_D.264              Bitstream 
CABREF3_Sand_D.yuv              Reconstructed YUV file
CABREF3_Sand_D.trc              Decoder trace file
----------------------------------------------------------------------
Encoder configuration:
Stream Name:             CABREF3_Sand_D
Stream Source:           Sand Video
Video Sequence:          Mobile  
Video Resolution:        CIF  
Video Frames:            50 
Frame/Field Coding:      Field coded
Entropy Coding:          CABAC  
GOP Structure:           IDR/P B/B B/B P/P ..
Slices per Picture:      1  
Conformance Point:       JVT-G050r1  
POC Type:                0  
Number Ref Frames:       4  
IDR:                     First frame  
Ref Pic List Reorder:    No  
Adapt Ref Pic Mark:      No
Constrained Intra Pred:  No
Weighted Pred (P):       No
Weighted Bipred (B):     No
Direct Prediction:       Temporal 
Direct 8x8 Inference:    On
Loop Filter:             On  
SEI:                     No  
VUI:                     No  
Number Slice Groups:     1
Long-term Ref Frames:    No
MMCO:                    No
Arbitrary Slice Order:   No
Redundant Slices:        No
