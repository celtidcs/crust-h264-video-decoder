Bitsteam Name		:FRExt3_Panasonic
Profile			:Hi
Level			:2.1
Category		:4:2:0 8
Sequence		:Foreman
Width			:352
Height			:288

Num of Frms		:11
Entropy Coding		:CABAC
IDR Intervals		:1st I picture only
Slice per Pic		:1
Mixed Slice Type	:No
POC type		:0

Coding Type		:FRM only
Num of Ref Frms		:4

Loop Filter		:On
Constrained Intra Flag	:Off

No of B Frms		:2
Direct Type		:Temporal
Direct8x8 Inference Flag:0
Stored B Pic		:No

Transform Mode		:Adaptive 8x8/4x4
Sequence Qmatrix	:On
Picture Qmatrix		:On

MMCO			:Off
RPSL			:Off

Weighted Pred		:Off
PCM Mode		:No
Chroma Offset		:No

SP Pic Periodicity	:No
VUI			:No
SEI			:No
HRD Parameters		:No
Partition Mode		:0

Conformance Point	:L047d10
Comments		:I - B - B - P

			:Display Order ->
			: 1st IDR - SPS all
			: 2nd B   - PPS fall-back rule
			: 3rd B   - PPS fall-back rule
			: 4th P   - PPS all - max_min
			: 5th B   - PPS all - default
			: 6th B   - PPS all - delta_scale
			: 7th I   - PPS fall-back rule
			: 8th B   - PPS all - default
			: 9th B   - PPS all - delta_scale
			:10th P   - 
			:11th P   - PPS fall-back rule
