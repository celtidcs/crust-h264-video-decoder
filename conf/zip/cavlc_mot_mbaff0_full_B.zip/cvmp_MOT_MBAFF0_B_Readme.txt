 Encoder Settings
Stream Name:             cvmp_mot_mbaff0_full_B.26l 
Stream Source:           Motorola
Video Sequence:          bus  
Video Resolution:        full  
Video Frames:            30 
Frame/Field Coding:      field  
Entropy Coding:          CAVLC  
Slice Types:             IBBP  
I Period:                15  
Slices per Picture:      1  
Conformance Point:       JVT-G050r1
POC Type:                0  
Number Ref Frames:       3  
IDR:                     First only  
Ref Pic List Reorder:    No  
Adapt Ref Pic Mark:      Off  
Constrained Intra Pred:  Off  
Weighted Pred (P):       Off  
Weighted Bipred (B):     Off  
Direct Prediction:       spatial  
Direct 8x8 Inference:    On  
Loop Filter:             On (default)  
SEI:                     No  
VUI:                     No  
Number Slice Groups:     1
Long-term Ref Frames:    No
MMCO:                    No
Arbitrary Slice Order:   No
Redundant Slices:        No
MB Qp Delta		 No  
