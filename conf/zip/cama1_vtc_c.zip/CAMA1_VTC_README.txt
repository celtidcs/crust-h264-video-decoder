Stream Name:  CAMA1_VTC_C
Stream Source:  Tut_VideoTele.com
Video Sequence:  Football
Video Resolution:  720x480 bottom field first
Video Frames:  4
Frame/Field Coding:  First frame IP field bottom field first, the rest are MBAFF  
Entropy Coding:  CABAC
Slice Types:  IPB
I Period:  First only  
Slices per Picture:  1  
Conformance Point:  JVT-I050

POC Type:  0
Number Reference Frames:  5
IDR:  First frame  
Ref Pic List Reordering:  No  
Adaptive Ref Pic Marking Mode:  Off  
Constrained Intra Prediction:  Off (Unconstrained)  
Weighted Prediction (P):  Off  
Weighted Biprediction (B):  Off  
Direct Prediction:  Spatial
Direct 8x8 Inference:  1
Loop Filter:  on
SEI:  No  
VUI:  No  
Number Slice Groups: 1
Long-term Ref Frames: No
MMCO: No
Slices per Picture: 1
Arbitrary Slice Order: No
Redundant Slices: No

