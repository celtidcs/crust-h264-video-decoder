Bitsteam Name		:FRExt2_Panasonic
Profile			:Hi
Level			:2.1
Category		:4:2:0 8
Sequence		:Mobile
Width			:352
Height			:288

Num of Frms		:15
Entropy Coding		:CAVLC
IDR Intervals		:All I pictures
Slice per Pic		:1
Mixed Slice Type	:No
POC type		:0

Coding Type		:MBAFF/AFF
Num of Ref Frms		:5

Loop Filter		:On
Constrained Intra Flag	:Off

No of B Frms		:2
Direct Type		:Temporal
Direct8x8 Inference Flag:1
Stored B Pic		:Yes

Transform Mode		:Adaptive 8x8/4x4
Sequence Qmatrix	:On
Picture Qmatrix		:On

MMCO			:On
RPSL			:On

Weighted Pred		:Off
PCM Mode		:No
Chroma Offset		:No

SP Pic Periodicity	:No
VUI			:No
SEI			:No
HRD Parameters		:No
Partition Mode		:0

Conformance Point	:L047d5
Comments		:I - Bs - B - P

			:Display Order ->
			: 1st IDR - FLD   SPS all
			: 2nd Bs  - MBAFF PPS all - delta_scale
			: 3rd B   - MBAFF PPS fall-back rule
			: 4th P   - FLD   PPS all - default
			: 5th Bs  - FLD   PPS fall-back rule
			: 6th B   - MBAFF PPS all - max_min
			: 7th p   - MBAFF PPS fall-back rule
			: 8th Bs  - MBAFF PPS fall-back rule
			: 9th B   - FLD   PPS fall-back rule
			:10th IDR - MBAFF SPS fall-back rule
			:11th Bs  - MBAFF PPS fall-back rule
			:12th B   - FLD   PPS fall-back rule
			:13th P   - FLD   
			:14th P   - MBAFF PPS all - delta_scale
			:15th P   - FLD   PPS all - max_min
