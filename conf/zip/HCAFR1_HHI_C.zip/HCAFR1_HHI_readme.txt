Bitsteam Name		:HCAFR1_HHI
Profile			:Hi
Level			:3.0
Category		:4:2:0 8
Sequence		:Foreman
Width			:352
Height			:288

Num of Frms		:10
Entropy Coding		:CABAC (adaptive initilaization)
IDR Intervals		:Only first pic
Slice per Pic		:1
Mixed Slice Type	:No
POC type		:0

Coding Type		:Frame only
Num of Ref Frms		:5

Loop Filter		:On
Constrained Intra Flag	:Off

No of B Frms		:2
Direct Type		:Spatial
Direct8x8 Inference Flag:1
Stored B Pic		:No

Transform Mode		:rd-based including 8x8
Sequence Qmatrix	:default flag
Picture Qmatrix		:Off

MMCO			:Off
RPSL			:Off

Weighted Pred		:Off
PCM Mode		:No
Chroma Offset		:No

SP Pic Periodicity	:No
VUI			:No
SEI			:No
HRD Parameters		:No
Partition Mode		:0

Conformance Point	:L050d3
Comments		:I - B - B - P
