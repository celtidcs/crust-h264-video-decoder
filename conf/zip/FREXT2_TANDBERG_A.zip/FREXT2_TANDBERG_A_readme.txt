Stream Name:             FREXT2_TANDBERG_A
Stream Source:           TANDBERG  
Video Sequence:          F1  
Video Resolution:        CIF - 4:2:2/8  
Video Frames:            5
Frame/Field Coding:      Frame  
Entropy Coding:          CAVLC  
Slice Types:             IPPPP 
I Period:                0  
Slices per Picture:      1  
Conformance Point:       JVT-L012d2  
POC Type:                0  
Number Ref Frames:       1  
IDR:                     First only  
Ref Pic List Reorder:    No  
Adapt Ref Pic Mark:      Off  
Constrained Intra Pred:  Off (Unconstrained)  
Weighted Pred (P):       Off  
Weighted Bipred (B):     Off  
Direct Prediction:       None  
Direct 8x8 Inference:    Off  
Loop Filter:             On  
SEI:                     No  
VUI:                     No  
Number Slice Groups:     1
Long-term Ref Frames:    No
MMCO:                    No
Arbitrary Slice Order:   No
Redundant Slices:        No
Gaps in frame_num:       No
