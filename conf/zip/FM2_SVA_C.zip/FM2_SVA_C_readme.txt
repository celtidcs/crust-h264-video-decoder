Stream Name:             FM2_SVA_C
Stream Source:           SVA & Tsinghua  
Video Sequence:          Foreman  
Video Resolution:        QCIF
Video Frames:            17
Frame/Field Coding:      Frame  
Entropy Coding:          CAVLC  
Slice Types:             IP  
Intra Period:            0  
Slices per Picture:      3  
Conformance Point:       JVT-G050r1  
POC Type:                1  
Number Ref Frames:       5  
Constrained Intra Pred:  Off (Unconstrained)  
Loop Filter:             On 
delta_QP always zero:    No
IDR:                     First Frame  
Ref Pic List Reorder:    No  
Adapt Ref Pic Mark:      Off  
Weighted Pred (P):       Off  
Weighted Bipred (B):     Off  
Direct Prediction:       None
Direct 8x8 Inference:    Off  
SEI:                     No  
VUI:                     No  
Number Slice Groups:     3
Long-term Ref Frames:    No
MMCO:                    No
Arbitrary Slice Order:   No
Redundant Slices:        No
