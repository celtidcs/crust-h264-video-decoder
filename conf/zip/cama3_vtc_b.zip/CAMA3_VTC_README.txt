Stream Name:  CAMA3_VTC_B
Stream Source:  Tut_VideoTele.com
Video Sequence:  Mobile
Video Resolution:  720x576
Video Frames:  4
Frame/Field Coding:  First frame IP field, the rest are MBAFF  
Entropy Coding:  CABAC
Slice Types:  IPB
I Period:  First only  
Slices per Picture:  1  
Conformance Point:  JVT-I050

POC Type:  0
Number Reference Frames:  5
IDR:  First frame  
Ref Pic List Reordering:  No  
Adaptive Ref Pic Marking Mode:  Off  
Constrained Intra Prediction:  Off (Unconstrained)  
Weighted Prediction (P):  Off  
Weighted Biprediction (B):  Off  
Direct Prediction:  Spatial
Direct 8x8 Inference:  1
Loop Filter:  on
SEI:  No  
VUI:  No  
Number Slice Groups: 1
Long-term Ref Frames: No
MMCO: No
Slices per Picture: 1
Arbitrary Slice Order: No
Redundant Slices: No

